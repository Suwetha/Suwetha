package com.training;

import java.util.List;

public interface StudentDAO {

	
	/** 
	    * This is the method to be used to list down
	    * a record from the Student table corresponding
	    * to a passed student id.
	    */
	   public List<Student> getStudent(Integer id);
	  // public Student getDummyStudent();
	   public Student deleteStudent(Integer id);
	   public List<Student> getAllStudents();
	   public void createStudent(Student student);
	   public Student updateStudent(Student student);
}
