package com.training;
import java.sql.Types;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;


public class StudentJDBCTemplate implements StudentDAO {	
	@SuppressWarnings("unused")
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	   
	   Student student=null;
	  /* public Student getDummyStudent()
	   {
		      String SQL = "select * from StudentMaster where name = 'DUMMY'";		
		      try{
		    	  student=jdbcTemplateObject.queryForObject(SQL, new Object[]{}, new StudentMapper());
		      }
		      catch(Throwable fault)
			{
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
	  
 }
		      return student;
	   }*/
	   
	   
	   public void createStudent(Student student)
	   {
		   

			try{
				
		         int[] types = { Types.INTEGER,Types.VARCHAR,Types.INTEGER };
		         
				Object[] params = {student.getId(),student.getName(),student.getAge()};
				//System.out.println(student.getName());
				jdbcTemplateObject.update("insert into studentMaster values(?,?,?)",params,types);
						
				
			   
				} catch (Throwable fault) {
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();
				}	  
			}
	   
	   
		
		
	   public Student updateStudent(Student student)
	   {
	Student list=null;
			
			try{
				int [] type={Types.INTEGER,Types.VARCHAR,Types.INTEGER};
				Object param[] ={student.getAge(),student.getName(),student.getId(),};
				jdbcTemplateObject.update("update StudentMaster set age=?,name=? where ID=?" ,param,type);
				
			}
			catch(Throwable fault){
				System.out.println(fault);
			}
			return list;
	   }
	   
	   public List<Student> getStudent(Integer id) {
		   List<Student> s=null;  
		   String SQL = "select * from StudentMaster where ID = ?";		
		      try
		      {
		    	   s=jdbcTemplateObject.query(SQL, new Object[]{id}, new StudentMapper());
		      }
		      catch(Throwable fault)
  			{
			System.out.println("Id Doesn't exists");
			fault.printStackTrace();
  	  
  			}
		      return s;
		   }
	   
	   
	   public List<Student> getAllStudents() {
		      String SQL = "select * from StudentMaster";
		      List<Student> studentList = null;
		      try{
		    	  studentList=jdbcTemplateObject.query(SQL, new Object[]{}, new StudentMapper());
		      }
		      catch(Throwable fault)
		    			{
					System.out.println("Got error.  Returning null (404)");
					fault.printStackTrace();
		    	  
		      }
		      return studentList;
		   }
	   
	   public Student deleteStudent(Integer id) {
		   
		      try{
		    	  student=(Student) jdbcTemplateObject.query("Delete from StudentMaster where ID = ?", new Object[]{id}, new StudentMapper());
		      }
		      catch(Throwable fault)
  			{
			System.out.println("Got error.  Returning null (404)");
			fault.printStackTrace();
  	  
    }
		      return student;
		   }
}
